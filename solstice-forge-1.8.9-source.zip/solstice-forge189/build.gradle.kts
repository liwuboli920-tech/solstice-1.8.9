plugins {
    idea
    java
    id("gg.essential.loom") version "0.10.0.+"
    // Forge 1.8.9 userdev 使用 pack200，JDK 14+ 已移除，需要这个插件才能在 JDK 17 下构建
    id("dev.architectury.architectury-pack200") version "0.1.3"
}

group = "com.solstice"
version = "1.0.0"

// 产物是 Java 8 字节码：Forge 1.8.9 原生要求 Java 8，
// 同时可以在 JRE 17（PojavLauncher 等）上运行；纯 Java，无本地库，因此 x64 / arm64 通用。
java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(8)
}

loom {
    silentMojangMappingsLicense()
    forge {
        pack200Provider.set(dev.architectury.pack200.java.Pack200Adapter())
    }
}

repositories {
    mavenCentral()
}

dependencies {
    minecraft("com.mojang:minecraft:1.8.9")
    mappings("de.oceanlabs.mcp:mcp_stable:22-1.8.9")
    forge("net.minecraftforge:forge:1.8.9-11.15.1.2318-1.8.9")
}

tasks.processResources {
    inputs.property("version", project.version)
    filesMatching("mcmod.info") {
        expand(mapOf("version" to project.version))
    }
}

tasks.jar {
    archiveBaseName.set("Solstice")
}

tasks.named<net.fabricmc.loom.task.RemapJarTask>("remapJar") {
    archiveBaseName.set("Solstice")
}
