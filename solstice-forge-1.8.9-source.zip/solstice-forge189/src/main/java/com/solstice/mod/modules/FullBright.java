package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;

/** 最大亮度。 */
public class FullBright extends Module {
    private float oldGamma = 1.0F;

    public FullBright() {
        super("FullBright", "Maximum brightness", Category.VISUAL);
    }

    @Override
    public void onEnable() {
        oldGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 100.0F;
    }

    @Override
    public void onDisable() {
        mc.gameSettings.gammaSetting = oldGamma;
    }

    @Override
    public void onTick() {
        // 防止被选项界面改回去
        if (mc.gameSettings.gammaSetting < 100.0F) mc.gameSettings.gammaSetting = 100.0F;
    }
}
