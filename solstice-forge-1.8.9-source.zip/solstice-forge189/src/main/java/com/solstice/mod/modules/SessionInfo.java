package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.MathHelper;

/** 左下角显示 FPS / Ping / 坐标 / 速度。 */
public class SessionInfo extends Module {
    private final BoolSetting fps = add(new BoolSetting("FPS", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", true));
    private final BoolSetting coords = add(new BoolSetting("Coordinates", true));
    private final BoolSetting speed = add(new BoolSetting("Speed", false));

    public SessionInfo() {
        super("SessionInfo", "Shows FPS, ping and coordinates", Category.VISUAL);
        listed = false;
    }

    @Override
    public void onRender2D(ScaledResolution sr, float partialTicks) {
        int lines = 0;
        if (fps.value) lines++;
        if (ping.value) lines++;
        if (coords.value) lines++;
        if (speed.value) lines++;

        int lh = mc.fontRendererObj.FONT_HEIGHT + 2;
        int y = sr.getScaledHeight() - lines * lh - 4;

        if (fps.value) y = line("FPS: §f" + Minecraft.getDebugFPS(), y, lh);
        if (ping.value) y = line("Ping: §f" + getPing() + " ms", y, lh);
        if (coords.value) {
            y = line(String.format("XYZ: §f%d %d %d",
                    MathHelper.floor_double(mc.thePlayer.posX),
                    MathHelper.floor_double(mc.thePlayer.posY),
                    MathHelper.floor_double(mc.thePlayer.posZ)), y, lh);
        }
        if (speed.value) {
            double dx = mc.thePlayer.posX - mc.thePlayer.prevPosX;
            double dz = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
            y = line(String.format("Speed: §f%.2f b/s", Math.sqrt(dx * dx + dz * dz) * 20.0), y, lh);
        }
    }

    private int line(String text, int y, int lh) {
        mc.fontRendererObj.drawStringWithShadow("§7" + text, 4, y, 0xFFFFFFFF);
        return y + lh;
    }

    private int getPing() {
        NetHandlerPlayClient handler = mc.getNetHandler();
        if (handler == null) return 0;
        NetworkPlayerInfo info = handler.getPlayerInfo(mc.thePlayer.getUniqueID());
        return info == null ? 0 : info.getResponseTime();
    }
}
