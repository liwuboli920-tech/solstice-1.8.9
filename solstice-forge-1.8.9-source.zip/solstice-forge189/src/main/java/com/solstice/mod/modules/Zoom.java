package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.NumSetting;
import org.lwjgl.input.Keyboard;

/** 缩放：启用时缩小视野。默认绑定 C。 */
public class Zoom extends Module {
    private final NumSetting factor = add(new NumSetting("Factor", 4.0, 1.5, 10.0, 0.5));
    private float oldFov = 70.0F;

    public Zoom() {
        super("Zoom", "Zooms the camera in", Category.VISUAL);
        setKey(Keyboard.KEY_C);
    }

    @Override
    public void onEnable() {
        oldFov = mc.gameSettings.fovSetting;
        mc.gameSettings.fovSetting = Math.max(5.0F, oldFov / factor.f());
    }

    @Override
    public void onDisable() {
        mc.gameSettings.fovSetting = oldFov;
    }
}
