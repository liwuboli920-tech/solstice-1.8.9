package com.solstice.mod.module;

import com.solstice.mod.gui.ClickGui;
import com.solstice.mod.modules.*;
import com.solstice.mod.util.Config;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    public static final int GUI_KEY = Keyboard.KEY_RSHIFT;
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final List<Module> modules = new ArrayList<Module>();

    private ModuleManager() {
    }

    public static void init() {
        // Player
        modules.add(new AutoTool());
        // Movement
        modules.add(new Sprint());
        // Visual
        modules.add(new Watermark());
        modules.add(new ArrayListModule());
        modules.add(new Keystrokes());
        modules.add(new SessionInfo());
        modules.add(new TargetHud());
        modules.add(new FullBright());
        modules.add(new Zoom());

        Config.load(modules);
        MinecraftForge.EVENT_BUS.register(new ModuleManager());
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public static List<Module> byCategory(Category category) {
        List<Module> out = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public static void saveConfig() {
        Config.save(modules);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || mc.thePlayer == null || mc.theWorld == null) return;
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (!Keyboard.getEventKeyState() || mc.currentScreen != null) return;
        int key = Keyboard.getEventKey();
        if (key == Keyboard.KEY_NONE) return;

        if (key == GUI_KEY) {
            mc.displayGuiScreen(new ClickGui());
            return;
        }
        for (Module m : modules) {
            if (m.getKey() == key) m.toggle();
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.gameSettings.showDebugInfo || mc.thePlayer == null) return;
        for (Module m : modules) {
            if (m.isEnabled()) m.onRender2D(event.resolution, event.partialTicks);
        }
    }
}
