package com.solstice.mod.module;

import com.solstice.mod.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getMinecraft();

    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<Setting>();

    /** 是否显示在 ArrayList 里（HUD 类模块通常为 false）。 */
    public boolean listed = true;

    private boolean enabled;
    private int key = Keyboard.KEY_NONE;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable();
        else onDisable();
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    /** 每个客户端 tick（仅在玩家存在且模块启用时调用）。 */
    public void onTick() {
    }

    /** 绘制 HUD（仅在模块启用时调用）。 */
    public void onRender2D(ScaledResolution sr, float partialTicks) {
    }
}
