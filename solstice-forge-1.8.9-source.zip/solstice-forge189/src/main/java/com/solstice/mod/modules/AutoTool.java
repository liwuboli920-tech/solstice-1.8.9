package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.BoolSetting;
import net.minecraft.block.Block;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;

/** 挖方块时自动切换到最快的工具。 */
public class AutoTool extends Module {
    private final BoolSetting switchBack = add(new BoolSetting("Switch back", true));
    private int previousSlot = -1;

    public AutoTool() {
        super("AutoTool", "Selects the fastest tool while mining", Category.PLAYER);
    }

    @Override
    public void onDisable() {
        restore();
    }

    @Override
    public void onTick() {
        MovingObjectPosition over = mc.objectMouseOver;
        boolean mining = mc.gameSettings.keyBindAttack.isKeyDown()
                && over != null
                && over.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK
                && mc.currentScreen == null;

        if (!mining) {
            restore();
            return;
        }

        Block block = mc.theWorld.getBlockState(over.getBlockPos()).getBlock();
        int best = mc.thePlayer.inventory.currentItem;
        float bestSpeed = speed(mc.thePlayer.inventory.getStackInSlot(best), block);

        for (int slot = 0; slot < 9; slot++) {
            float s = speed(mc.thePlayer.inventory.getStackInSlot(slot), block);
            if (s > bestSpeed) {
                bestSpeed = s;
                best = slot;
            }
        }

        if (best != mc.thePlayer.inventory.currentItem) {
            if (previousSlot == -1) previousSlot = mc.thePlayer.inventory.currentItem;
            mc.thePlayer.inventory.currentItem = best;
        }
    }

    private void restore() {
        if (previousSlot != -1 && switchBack.value && mc.thePlayer != null) {
            mc.thePlayer.inventory.currentItem = previousSlot;
        }
        previousSlot = -1;
    }

    private float speed(ItemStack stack, Block block) {
        return stack == null ? 1.0F : stack.getStrVsBlock(block);
    }
}
