package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.NumSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;

/** 显示 WASD / 鼠标按键状态。 */
public class Keystrokes extends Module {
    private final NumSetting x = add(new NumSetting("X", 6, 0, 400, 2));
    private final NumSetting y = add(new NumSetting("Y", 60, 0, 300, 2));

    public Keystrokes() {
        super("Keystrokes", "Shows pressed keys", Category.VISUAL);
        listed = false;
    }

    @Override
    public void onRender2D(ScaledResolution sr, float partialTicks) {
        int size = 22;
        int gap = 2;
        int ox = x.i();
        int oy = y.i();

        box(mc.gameSettings.keyBindForward, ox + size + gap, oy, size, size);
        box(mc.gameSettings.keyBindLeft, ox, oy + size + gap, size, size);
        box(mc.gameSettings.keyBindBack, ox + size + gap, oy + size + gap, size, size);
        box(mc.gameSettings.keyBindRight, ox + 2 * (size + gap), oy + size + gap, size, size);

        int w = (size * 3 + gap * 2 - gap) / 2;
        mouse("LMB", mc.gameSettings.keyBindAttack, ox, oy + 2 * (size + gap), w, 18);
        mouse("RMB", mc.gameSettings.keyBindUseItem, ox + w + gap, oy + 2 * (size + gap), w, 18);
    }

    private void box(KeyBinding key, int bx, int by, int w, int h) {
        draw(org.lwjgl.input.Keyboard.getKeyName(key.getKeyCode()), key.isKeyDown(), bx, by, w, h);
    }

    private void mouse(String label, KeyBinding key, int bx, int by, int w, int h) {
        draw(label, key.isKeyDown(), bx, by, w, h);
    }

    private void draw(String label, boolean down, int bx, int by, int w, int h) {
        Gui.drawRect(bx, by, bx + w, by + h, down ? 0xB0FFFFFF : 0x80000000);
        int tw = mc.fontRendererObj.getStringWidth(label);
        mc.fontRendererObj.drawString(label,
                bx + (w - tw) / 2,
                by + (h - mc.fontRendererObj.FONT_HEIGHT) / 2 + 1,
                down ? 0xFF000000 : 0xFFFFFFFF);
    }
}
