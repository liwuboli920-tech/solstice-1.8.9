package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.BoolSetting;

/** 自动疾跑（Toggle Sprint）。 */
public class Sprint extends Module {
    private final BoolSetting onlyForward = add(new BoolSetting("Only forward", true));

    public Sprint() {
        super("Sprint", "Automatically sprints while moving", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.thePlayer.isSneaking() || mc.thePlayer.isUsingItem() || mc.thePlayer.isCollidedHorizontally) return;
        if (mc.thePlayer.getFoodStats().getFoodLevel() <= 6) return;
        boolean moving = onlyForward.value
                ? mc.thePlayer.movementInput.moveForward > 0
                : (mc.thePlayer.movementInput.moveForward != 0 || mc.thePlayer.movementInput.moveStrafe != 0);
        if (moving) mc.thePlayer.setSprinting(true);
    }
}
