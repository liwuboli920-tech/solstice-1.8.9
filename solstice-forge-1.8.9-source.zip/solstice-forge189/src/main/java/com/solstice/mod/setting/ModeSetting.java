package com.solstice.mod.setting;

public class ModeSetting extends Setting {
    public final String[] modes;
    public int index;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(defaultMode)) index = i;
        }
    }

    public String get() {
        return modes[index];
    }

    public boolean is(String mode) {
        return get().equalsIgnoreCase(mode);
    }

    public void cycle(int direction) {
        index = ((index + direction) % modes.length + modes.length) % modes.length;
    }

    @Override
    public String display() {
        return get();
    }

    @Override
    public void load(String raw) {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(raw)) index = i;
        }
    }

    @Override
    public String save() {
        return get();
    }
}
