package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.ModeSetting;
import net.minecraft.client.gui.ScaledResolution;

public class Watermark extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Simple", "Simple", "Version"));

    public Watermark() {
        super("Watermark", "Shows the client name", Category.VISUAL);
        listed = false;
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onRender2D(ScaledResolution sr, float partialTicks) {
        String text = style.is("Version") ? "§bSolstice §7v1.0.0" : "§bSolstice";
        mc.fontRendererObj.drawStringWithShadow(text, 4, 4, 0xFFFFFFFF);
    }
}
