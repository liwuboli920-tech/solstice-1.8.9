package com.solstice.mod.gui;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.module.ModuleManager;
import com.solstice.mod.setting.BoolSetting;
import com.solstice.mod.setting.ModeSetting;
import com.solstice.mod.setting.NumSetting;
import com.solstice.mod.setting.Setting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 简易 ClickGUI（右 Shift 打开）。
 * 左键：开关模块 / 调整设置(+)；右键：展开设置 / 调整设置(-)；中键：绑定按键（ESC 清除）。
 */
public class ClickGui extends GuiScreen {
    private static final int PANEL_W = 110;
    private static final int ROW_H = 14;

    private static final class Row {
        final int x, y, w, h;
        final Runnable left, right, middle;

        Row(int x, int y, int w, int h, Runnable left, Runnable right, Runnable middle) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
            this.right = right;
            this.middle = middle;
        }

        boolean hit(int mx, int my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Row> rows = new ArrayList<Row>();
    private final Set<Module> expanded = new HashSet<Module>();
    private Module listening;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawRect(0, 0, width, height, 0x80000000);
        rows.clear();

        int px = 10;
        for (Category category : Category.values()) {
            int y = 10;
            Gui.drawRect(px, y, px + PANEL_W, y + ROW_H + 2, 0xFF1E1E1E);
            fontRendererObj.drawStringWithShadow(category.label, px + 4, y + 4, 0xFF55FFFF);
            y += ROW_H + 2;

            for (final Module m : ModuleManager.byCategory(category)) {
                int bg = m.isEnabled() ? 0xE0307080 : 0xE0202020;
                Gui.drawRect(px, y, px + PANEL_W, y + ROW_H, bg);
                String label = (listening == m) ? "Press a key..." : m.name;
                fontRendererObj.drawStringWithShadow(label, px + 4, y + 3, 0xFFFFFFFF);
                if (m.getKey() != Keyboard.KEY_NONE && listening != m) {
                    String k = "[" + Keyboard.getKeyName(m.getKey()) + "]";
                    fontRendererObj.drawStringWithShadow(k, px + PANEL_W - fontRendererObj.getStringWidth(k) - 3, y + 3, 0xFFAAAAAA);
                }
                rows.add(new Row(px, y, PANEL_W, ROW_H,
                        new Runnable() { public void run() { m.toggle(); } },
                        new Runnable() { public void run() { if (!expanded.remove(m)) expanded.add(m); } },
                        new Runnable() { public void run() { listening = m; } }));
                y += ROW_H;

                if (expanded.contains(m)) {
                    for (final Setting s : m.settings) {
                        Gui.drawRect(px, y, px + PANEL_W, y + ROW_H, 0xE0101010);
                        fontRendererObj.drawString(s.name, px + 8, y + 3, 0xFFCCCCCC);
                        String v = s.display();
                        fontRendererObj.drawString(v, px + PANEL_W - fontRendererObj.getStringWidth(v) - 3, y + 3, 0xFF55FF55);
                        rows.add(new Row(px, y, PANEL_W, ROW_H,
                                new Runnable() { public void run() { adjust(s, 1); } },
                                new Runnable() { public void run() { adjust(s, -1); } },
                                null));
                        y += ROW_H;
                    }
                }
            }
            px += PANEL_W + 8;
        }

        fontRendererObj.drawStringWithShadow(
                "LMB toggle / +   RMB settings / -   MMB bind   RShift close",
                10, height - 14, 0xFFAAAAAA);
    }

    private void adjust(Setting s, int dir) {
        if (s instanceof BoolSetting) ((BoolSetting) s).toggle();
        else if (s instanceof NumSetting) ((NumSetting) s).change(dir);
        else if (s instanceof ModeSetting) ((ModeSetting) s).cycle(dir);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws IOException {
        for (Row r : rows) {
            if (!r.hit(mouseX, mouseY)) continue;
            Runnable action = button == 0 ? r.left : button == 1 ? r.right : r.middle;
            if (action != null) action.run();
            return;
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (listening != null) {
            listening.setKey(keyCode == Keyboard.KEY_ESCAPE ? Keyboard.KEY_NONE : keyCode);
            listening = null;
            return;
        }
        if (keyCode == ModuleManager.GUI_KEY) {
            mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public void onGuiClosed() {
        ModuleManager.saveConfig();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
