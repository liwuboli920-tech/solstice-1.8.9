package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;

/** 准星指向生物时，在屏幕中下方显示名称与血量。 */
public class TargetHud extends Module {
    private EntityLivingBase target;
    private long lastSeen;

    public TargetHud() {
        super("TargetHUD", "Shows health of the entity you look at", Category.VISUAL);
        listed = false;
    }

    @Override
    public void onTick() {
        MovingObjectPosition over = mc.objectMouseOver;
        if (over != null
                && over.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY
                && over.entityHit instanceof EntityLivingBase) {
            target = (EntityLivingBase) over.entityHit;
            lastSeen = System.currentTimeMillis();
        }
    }

    @Override
    public void onRender2D(ScaledResolution sr, float partialTicks) {
        if (target == null || target.isDead || System.currentTimeMillis() - lastSeen > 2000L) return;

        int w = 120;
        int h = 30;
        int x = sr.getScaledWidth() / 2 + 20;
        int y = sr.getScaledHeight() / 2 + 20;

        Gui.drawRect(x, y, x + w, y + h, 0x90000000);
        mc.fontRendererObj.drawStringWithShadow(target.getName(), x + 4, y + 4, 0xFFFFFFFF);

        float max = Math.max(1.0F, target.getMaxHealth());
        float ratio = Math.max(0.0F, Math.min(1.0F, target.getHealth() / max));
        int barX = x + 4;
        int barY = y + 18;
        int barW = w - 8;
        Gui.drawRect(barX, barY, barX + barW, barY + 6, 0xFF303030);
        int color = ratio > 0.6F ? 0xFF55FF55 : ratio > 0.3F ? 0xFFFFAA00 : 0xFFFF5555;
        Gui.drawRect(barX, barY, barX + (int) (barW * ratio), barY + 6, color);
    }
}
