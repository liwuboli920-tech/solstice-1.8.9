package com.solstice.mod.setting;

public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    /** 用于显示 / 配置保存。 */
    public abstract String display();

    /** 从配置文件恢复（字符串形式）。 */
    public abstract void load(String raw);

    /** 保存为字符串。 */
    public abstract String save();
}
