package com.solstice.mod.setting;

public class BoolSetting extends Setting {
    public boolean value;

    public BoolSetting(String name, boolean value) {
        super(name);
        this.value = value;
    }

    public void toggle() {
        value = !value;
    }

    @Override
    public String display() {
        return value ? "On" : "Off";
    }

    @Override
    public void load(String raw) {
        value = Boolean.parseBoolean(raw);
    }

    @Override
    public String save() {
        return Boolean.toString(value);
    }
}
