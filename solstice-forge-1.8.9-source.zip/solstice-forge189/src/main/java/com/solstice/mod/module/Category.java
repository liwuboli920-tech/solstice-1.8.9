package com.solstice.mod.module;

public enum Category {
    PLAYER("Player"),
    MOVEMENT("Movement"),
    VISUAL("Visual");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
