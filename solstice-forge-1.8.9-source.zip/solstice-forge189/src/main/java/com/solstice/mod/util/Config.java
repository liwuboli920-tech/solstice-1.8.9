package com.solstice.mod.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.solstice.mod.module.Module;
import com.solstice.mod.setting.Setting;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.List;

/** 简单的 JSON 配置：config/solstice.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {
    }

    private static File file() {
        File dir = new File(Minecraft.getMinecraft().mcDataDir, "config");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "solstice.json");
    }

    public static void save(List<Module> modules) {
        JsonObject root = new JsonObject();
        for (Module m : modules) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());
            JsonObject s = new JsonObject();
            for (Setting setting : m.settings) {
                s.addProperty(setting.name, setting.save());
            }
            o.add("settings", s);
            root.add(m.name, o);
        }
        try (Writer w = new FileWriter(file())) {
            GSON.toJson(root, w);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void load(List<Module> modules) {
        File f = file();
        if (!f.exists()) return;
        try (Reader r = new FileReader(f)) {
            JsonElement parsed = new JsonParser().parse(r);
            if (parsed == null || !parsed.isJsonObject()) return;
            JsonObject root = parsed.getAsJsonObject();
            for (Module m : modules) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting setting : m.settings) {
                        if (s.has(setting.name)) setting.load(s.get(setting.name).getAsString());
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.setEnabled(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
