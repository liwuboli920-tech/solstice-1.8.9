package com.solstice.mod.setting;

public class NumSetting extends Setting {
    public double value;
    public final double min, max, step;

    public NumSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public void change(int direction) {
        set(value + direction * step);
    }

    public void set(double v) {
        value = Math.max(min, Math.min(max, v));
        // 对齐到 step，避免浮点累计误差
        value = Math.round(value / step) * step;
        value = Math.max(min, Math.min(max, value));
    }

    public float f() {
        return (float) value;
    }

    public int i() {
        return (int) Math.round(value);
    }

    @Override
    public String display() {
        return step >= 1 ? Integer.toString(i()) : String.format("%.2f", value);
    }

    @Override
    public void load(String raw) {
        try {
            set(Double.parseDouble(raw));
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    public String save() {
        return Double.toString(value);
    }
}
