package com.solstice.mod;

import com.solstice.mod.module.ModuleManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = SolsticeMod.MODID, name = SolsticeMod.NAME, version = SolsticeMod.VERSION,
        acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class SolsticeMod {
    public static final String MODID = "solstice";
    public static final String NAME = "Solstice";
    public static final String VERSION = "1.0.0";

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModuleManager.init();
    }
}
