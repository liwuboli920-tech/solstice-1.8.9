package com.solstice.mod.modules;

import com.solstice.mod.module.Category;
import com.solstice.mod.module.Module;
import com.solstice.mod.module.ModuleManager;
import com.solstice.mod.setting.BoolSetting;
import net.minecraft.client.gui.ScaledResolution;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** 右上角显示已启用模块列表。 */
public class ArrayListModule extends Module {
    private final BoolSetting background = add(new BoolSetting("Background", true));

    public ArrayListModule() {
        super("ArrayList", "Lists enabled modules", Category.VISUAL);
        listed = false;
    }

    @Override
    public void onRender2D(ScaledResolution sr, float partialTicks) {
        List<Module> shown = new ArrayList<Module>();
        for (Module m : ModuleManager.all()) {
            if (m.isEnabled() && m.listed) shown.add(m);
        }
        Collections.sort(shown, new Comparator<Module>() {
            @Override
            public int compare(Module a, Module b) {
                return mc.fontRendererObj.getStringWidth(b.name) - mc.fontRendererObj.getStringWidth(a.name);
            }
        });

        int y = 2;
        int h = mc.fontRendererObj.FONT_HEIGHT + 2;
        for (Module m : shown) {
            int w = mc.fontRendererObj.getStringWidth(m.name);
            int x = sr.getScaledWidth() - w - 4;
            if (background.value) {
                net.minecraft.client.gui.Gui.drawRect(x - 2, y - 1, sr.getScaledWidth(), y + h - 1, 0x90000000);
            }
            mc.fontRendererObj.drawStringWithShadow(m.name, x, y, rainbow(y));
            y += h;
        }
    }

    private int rainbow(int offset) {
        float hue = ((System.currentTimeMillis() + offset * 10L) % 3000L) / 3000.0F;
        return java.awt.Color.HSBtoRGB(hue, 0.55F, 1.0F);
    }
}
