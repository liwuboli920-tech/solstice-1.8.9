# Solstice — Forge 1.8.9 (Java 重写版)

原项目是《我的世界》**基岩版** 1.21.44 的 C++ 注入式客户端，无法直接转成 Java mod，
因此这里是按其模块分类（Player / Movement / Visual）用 Java 重新实现的 Forge 1.8.9 mod。

## 已实现的模块
| 分类 | 模块 |
|---|---|
| Player | AutoTool |
| Movement | Sprint |
| Visual | Watermark, ArrayList, Keystrokes, SessionInfo, TargetHUD, FullBright, Zoom (默认 C) |

- **右 Shift** 打开 ClickGUI：左键开关/调整(+)，右键展开设置/调整(-)，中键绑定按键。
- 配置保存在 `.minecraft/config/solstice.json`。

## 构建
需要 **JDK 17**（构建机器；产物是 Java 8 字节码，JRE 8 / 17 都能运行）：

    ./gradlew build        # Windows: gradlew.bat build

产物：`build/libs/Solstice-1.0.0.jar`，放进 `.minecraft/mods/`（需要已安装 Forge 1.8.9-11.15.1.2318）。

没有电脑？把整个目录推到 GitHub，`.github/workflows/build.yml` 会自动构建，
在 Actions 页面下载 `Solstice-1.8.9` 产物即可。

## JRE 17 / arm64
- mod 是纯 Java，没有本地库，x64 与 arm64 通用。
- 1.8.9 + Forge 本身在 JRE 17 上运行需要启动器配合（PojavLauncher / Amethyst 等已内置处理）；
  使用普通启动器时需加 JVM 参数，如：
  `--add-opens java.base/java.lang=ALL-UNNAMED --add-opens java.base/java.util=ALL-UNNAMED --add-opens java.base/sun.nio.ch=ALL-UNNAMED`
  以及 arm64 版 LWJGL 2 natives（由启动器提供）。
